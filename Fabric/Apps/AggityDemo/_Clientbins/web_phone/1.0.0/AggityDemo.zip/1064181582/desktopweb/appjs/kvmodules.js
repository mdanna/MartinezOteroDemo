define('applicationController',{
    appInit: function(params) {
        skinsInit();
        voltmx.mvc.registry.add("com.hcl.demo.aggity.CheckboxField", "CheckboxField", "CheckboxFieldController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.aggity",
            "classname": "CheckboxField",
            "name": "com.hcl.demo.aggity.CheckboxField"
        });
        voltmx.mvc.registry.add("com.hcl.demo.aggity.DateField", "DateField", "DateFieldController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.aggity",
            "classname": "DateField",
            "name": "com.hcl.demo.aggity.DateField"
        });
        voltmx.mvc.registry.add("com.hcl.demo.aggity.EditField", "EditField", "EditFieldController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.aggity",
            "classname": "EditField",
            "name": "com.hcl.demo.aggity.EditField"
        });
        voltmx.mvc.registry.add("com.hcl.demo.aggity.HomePageButton", "HomePageButton", "HomePageButtonController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.aggity",
            "classname": "HomePageButton",
            "name": "com.hcl.demo.aggity.HomePageButton"
        });
        voltmx.mvc.registry.add("com.hcl.demo.aggity.SimpleHeader", "SimpleHeader", "SimpleHeaderController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.aggity",
            "classname": "SimpleHeader",
            "name": "com.hcl.demo.aggity.SimpleHeader"
        });
        voltmx.mvc.registry.add("com.hcl.demo.otero.IncidenciasItem", "IncidenciasItem", "IncidenciasItemController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.otero",
            "classname": "IncidenciasItem",
            "name": "com.hcl.demo.otero.IncidenciasItem"
        });
        voltmx.mvc.registry.add("com.hcl.demo.otero.LabelHeader", "LabelHeader", "LabelHeaderController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.otero",
            "classname": "LabelHeader",
            "name": "com.hcl.demo.otero.LabelHeader"
        });
        voltmx.mvc.registry.add("com.hcl.demo.otero.LabelHeaderSort", "LabelHeaderSort", "LabelHeaderSortController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.otero",
            "classname": "LabelHeaderSort",
            "name": "com.hcl.demo.otero.LabelHeaderSort"
        });
        voltmx.mvc.registry.add("comhcl.demo.aggity.HemburgerMenuItem", "HemburgerMenuItem", "HemburgerMenuItemController");
        voltmx.application.registerMaster({
            "namespace": "comhcl.demo.aggity",
            "classname": "HemburgerMenuItem",
            "name": "comhcl.demo.aggity.HemburgerMenuItem"
        });
        voltmx.mvc.registry.add("com.hcl.demo.aggity.HamburgerMenu", "HamburgerMenu", "HamburgerMenuController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.aggity",
            "classname": "HamburgerMenu",
            "name": "com.hcl.demo.aggity.HamburgerMenu"
        });
        voltmx.mvc.registry.add("frmHome", "frmHome", "frmHomeController");
        voltmx.mvc.registry.add("frmLogin", "frmLogin", "frmLoginController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new voltmx.mvc.Navigation("frmLogin").navigate();
    }
});

define("com/hcl/demo/aggity/CheckboxField/userCheckboxFieldController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        initGettersSetters() {
            defineGetter(this, 'selected', () => {
                return this.view.checkbox.selectedIndex === 0;
            });
            defineSetter(this, 'selected', value => {
                this.view.checkbox.selectedIndex = value ? 0 : 1;
            });
        }
    };
});
define("com/hcl/demo/aggity/CheckboxField/CheckboxFieldControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/aggity/CheckboxField/CheckboxFieldController", ["com/hcl/demo/aggity/CheckboxField/userCheckboxFieldController", "com/hcl/demo/aggity/CheckboxField/CheckboxFieldControllerActions"], function() {
    var controller = require("com/hcl/demo/aggity/CheckboxField/userCheckboxFieldController");
    var actions = require("com/hcl/demo/aggity/CheckboxField/CheckboxFieldControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "label", function(val) {
            this.view.lblSolucionado.text = val;
        });
        defineGetter(this, "label", function() {
            return this.view.lblSolucionado.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/aggity/CheckboxField/CheckboxField',[],function() {
    return function(controller) {
        var CheckboxField = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "40dp",
            "id": "CheckboxField",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "CheckboxField"), extendConfig({}, controller.args[1], "CheckboxField"), extendConfig({}, controller.args[2], "CheckboxField"));
        CheckboxField.setDefaultUnit(voltmx.flex.DP);
        var lblSolucionado = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblSolucionado",
            "isVisible": true,
            "left": "2%",
            "skin": "lblBlack80",
            "text": "¿Esta solucionado?",
            "textStyle": {},
            "top": "0dp",
            "width": "48%",
            "zIndex": 1
        }, controller.args[0], "lblSolucionado"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSolucionado"), extendConfig({}, controller.args[2], "lblSolucionado"));
        var checkbox = new voltmx.ui.Switch(extendConfig({
            "centerY": "50%",
            "height": "32dp",
            "id": "checkbox",
            "isVisible": true,
            "leftSideText": "ON",
            "right": 0,
            "rightSideText": "OFF",
            "selectedIndex": 1,
            "skin": "sknSwitch",
            "top": "0dp",
            "width": "60dp",
            "zIndex": 1
        }, controller.args[0], "checkbox"), extendConfig({
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "checkbox"), extendConfig({}, controller.args[2], "checkbox"));
        CheckboxField.add(lblSolucionado, checkbox);
        return CheckboxField;
    }
})
;
define('com/hcl/demo/aggity/CheckboxField/CheckboxFieldConfig',[],function() {
    return {
        "properties": [{
            "name": "label",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selected",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/aggity/DateField/userDateFieldController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        initGettersSetters() {},
        getDate() {
            const dc = this.view.calWidget.dateComponents;
            const day = dc[0] + '';
            const month = dc[1] + '';
            const year = dc[2] + '';
            return `${day.length < 2 ? '0'+ day : day}/${month.length < 2 ? '0'+ month : month}/${year}`;
        },
        resetDate() {
            const now = new Date();
            this.view.calWidget.dateComponents = [now.getDate(), now.getMonth() + 1, now.getFullYear(), 0, 0, 0];
        }
    };
});
define("com/hcl/demo/aggity/DateField/DateFieldControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/aggity/DateField/DateFieldController", ["com/hcl/demo/aggity/DateField/userDateFieldController", "com/hcl/demo/aggity/DateField/DateFieldControllerActions"], function() {
    var controller = require("com/hcl/demo/aggity/DateField/userDateFieldController");
    var actions = require("com/hcl/demo/aggity/DateField/DateFieldControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/aggity/DateField/DateField',[],function() {
    return function(controller) {
        var DateField = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "40dp",
            "id": "DateField",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "DateField"), extendConfig({}, controller.args[1], "DateField"), extendConfig({}, controller.args[2], "DateField"));
        DateField.setDefaultUnit(voltmx.flex.DP);
        var lblFecha = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblFecha",
            "isVisible": true,
            "left": "2%",
            "skin": "lblBlack80",
            "text": "Fecha:",
            "textStyle": {},
            "top": "0dp",
            "width": "48%",
            "zIndex": 1
        }, controller.args[0], "lblFecha"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblFecha"), extendConfig({}, controller.args[2], "lblFecha"));
        var flxDivider = new voltmx.ui.FlexScrollContainer(extendConfig({
            "allowHorizontalBounce": false,
            "allowVerticalBounce": true,
            "bottom": 0,
            "bounces": true,
            "clipBounds": true,
            "enableScrolling": true,
            "height": "1dp",
            "horizontalScrollIndicator": true,
            "id": "flxDivider",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "pagingEnabled": false,
            "right": 0,
            "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
            "skin": "sknFlxDivider",
            "verticalScrollIndicator": true,
            "width": "50%",
            "zIndex": 1
        }, controller.args[0], "flxDivider"), extendConfig({}, controller.args[1], "flxDivider"), extendConfig({}, controller.args[2], "flxDivider"));
        flxDivider.setDefaultUnit(voltmx.flex.DP);
        flxDivider.add();
        var calWidget = new voltmx.ui.Calendar(extendConfig({
            "calendarIcon": "calbtn.png",
            "centerY": "50%",
            "dateComponents": [30, 9, 2022, 0, 0, 0],
            "dateFormat": "dd/MM/yyyy",
            "day": 30,
            "formattedDate": "30/09/2022",
            "height": "40dp",
            "hour": 0,
            "id": "calWidget",
            "isVisible": true,
            "left": "50%",
            "minutes": 0,
            "month": 9,
            "seconds": 0,
            "skin": "sknCalendar",
            "top": "0dp",
            "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
            "width": "50%",
            "year": 2022,
            "zIndex": 1
        }, controller.args[0], "calWidget"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "calWidget"), extendConfig({
            "noOfMonths": 1
        }, controller.args[2], "calWidget"));
        DateField.add(lblFecha, flxDivider, calWidget);
        DateField.compInstData = {}
        return DateField;
    }
})
;
define('com/hcl/demo/aggity/DateField/DateFieldConfig',[],function() {
    return {
        "properties": [],
        "apis": ["getDate", "resetDate"],
        "events": []
    }
});

define("com/hcl/demo/aggity/EditField/userEditFieldController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/aggity/EditField/EditFieldControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/aggity/EditField/EditFieldController", ["com/hcl/demo/aggity/EditField/userEditFieldController", "com/hcl/demo/aggity/EditField/EditFieldControllerActions"], function() {
    var controller = require("com/hcl/demo/aggity/EditField/userEditFieldController");
    var actions = require("com/hcl/demo/aggity/EditField/EditFieldControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.txtField.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.txtField.text;
        });
        defineSetter(this, "placeholder", function(val) {
            this.view.txtField.placeholder = val;
        });
        defineGetter(this, "placeholder", function() {
            return this.view.txtField.placeholder;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/aggity/EditField/EditField',[],function() {
    return function(controller) {
        var EditField = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "40dp",
            "id": "EditField",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "EditField"), extendConfig({}, controller.args[1], "EditField"), extendConfig({}, controller.args[2], "EditField"));
        EditField.setDefaultUnit(voltmx.flex.DP);
        var txtField = new voltmx.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "focusSkin": "sknEditField",
            "height": "39dp",
            "id": "txtField",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "placeholder": "Placeholder",
            "secureTextEntry": false,
            "skin": "sknEditField",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "txtField"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtField"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "sknEditFieldPlaceholder"
        }, controller.args[2], "txtField"));
        var flxDivider = new voltmx.ui.FlexScrollContainer(extendConfig({
            "allowHorizontalBounce": false,
            "allowVerticalBounce": true,
            "bounces": true,
            "clipBounds": true,
            "enableScrolling": true,
            "height": "1dp",
            "horizontalScrollIndicator": true,
            "id": "flxDivider",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "pagingEnabled": false,
            "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
            "skin": "sknFlxDivider",
            "top": "0dp",
            "verticalScrollIndicator": true,
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxDivider"), extendConfig({}, controller.args[1], "flxDivider"), extendConfig({}, controller.args[2], "flxDivider"));
        flxDivider.setDefaultUnit(voltmx.flex.DP);
        flxDivider.add();
        EditField.add(txtField, flxDivider);
        EditField.compInstData = {}
        return EditField;
    }
})
;
define('com/hcl/demo/aggity/EditField/EditFieldConfig',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "placeholder",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/aggity/HomePageButton/userHomePageButtonController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.onClick = () => this.onClickButton();
                    this.initDone = true;
                }
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        onClickButton() {}
    };
});
define("com/hcl/demo/aggity/HomePageButton/HomePageButtonControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/aggity/HomePageButton/HomePageButtonController", ["com/hcl/demo/aggity/HomePageButton/userHomePageButtonController", "com/hcl/demo/aggity/HomePageButton/HomePageButtonControllerActions"], function() {
    var controller = require("com/hcl/demo/aggity/HomePageButton/userHomePageButtonController");
    var actions = require("com/hcl/demo/aggity/HomePageButton/HomePageButtonControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "icon", function(val) {
            this.view.lblIcon.text = val;
        });
        defineGetter(this, "icon", function() {
            return this.view.lblIcon.text;
        });
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/aggity/HomePageButton/HomePageButton',[],function() {
    return function(controller) {
        var HomePageButton = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "80dp",
            "id": "HomePageButton",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0f1fbd2e9a5fb4e",
            "top": "0dp",
            "width": "80dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "HomePageButton"), extendConfig({}, controller.args[1], "HomePageButton"), extendConfig({}, controller.args[2], "HomePageButton"));
        HomePageButton.setDefaultUnit(voltmx.flex.DP);
        var flxIcon = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "66%",
            "id": "flxIcon",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxIcon"), extendConfig({}, controller.args[1], "flxIcon"), extendConfig({}, controller.args[2], "flxIcon"));
        flxIcon.setDefaultUnit(voltmx.flex.DP);
        var lblIcon = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "60dp",
            "id": "lblIcon",
            "isVisible": true,
            "left": "33dp",
            "skin": "sknIconGrey250",
            "text": "",
            "textStyle": {},
            "top": "7dp",
            "width": "60dp",
            "zIndex": 1
        }, controller.args[0], "lblIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblIcon"), extendConfig({}, controller.args[2], "lblIcon"));
        flxIcon.add(lblIcon);
        var flxTitle = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "33%",
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxTitle"), extendConfig({}, controller.args[1], "flxTitle"), extendConfig({}, controller.args[2], "flxTitle"));
        flxTitle.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0f9af3f061a8e48",
            "text": "Home",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        flxTitle.add(lblTitle);
        HomePageButton.add(flxIcon, flxTitle);
        HomePageButton.compInstData = {}
        return HomePageButton;
    }
})
;
define('com/hcl/demo/aggity/HomePageButton/HomePageButtonConfig',[],function() {
    return {
        "properties": [{
            "name": "icon",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickButton"]
    }
});

define("com/hcl/demo/aggity/SimpleHeader/userSimpleHeaderController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/aggity/SimpleHeader/SimpleHeaderControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/aggity/SimpleHeader/SimpleHeaderController", ["com/hcl/demo/aggity/SimpleHeader/userSimpleHeaderController", "com/hcl/demo/aggity/SimpleHeader/SimpleHeaderControllerActions"], function() {
    var controller = require("com/hcl/demo/aggity/SimpleHeader/userSimpleHeaderController");
    var actions = require("com/hcl/demo/aggity/SimpleHeader/SimpleHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "leftIcon", function(val) {
            this.view.lblLeftIcon.text = val;
        });
        defineGetter(this, "leftIcon", function() {
            return this.view.lblLeftIcon.text;
        });
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickLeft_d80b26b75c6e4e77953f5bad01684341 = function() {
        if (this.onClickLeft) {
            this.onClickLeft.apply(this, arguments);
        }
    }
    return controller;
});

define('com/hcl/demo/aggity/SimpleHeader/SimpleHeader',[],function() {
    return function(controller) {
        var SimpleHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "7%",
            "id": "SimpleHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBlack",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "SimpleHeader"), extendConfig({}, controller.args[1], "SimpleHeader"), extendConfig({}, controller.args[2], "SimpleHeader"));
        SimpleHeader.setDefaultUnit(voltmx.flex.DP);
        var flxLeftIcon = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxLeftIcon",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_onClickLeft_d80b26b75c6e4e77953f5bad01684341,
            "skin": "slFbox",
            "top": "0%",
            "width": "50dp",
            "zIndex": 1
        }, controller.args[0], "flxLeftIcon"), extendConfig({}, controller.args[1], "flxLeftIcon"), extendConfig({}, controller.args[2], "flxLeftIcon"));
        flxLeftIcon.setDefaultUnit(voltmx.flex.DP);
        var lblLeftIcon = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblLeftIcon",
            "isVisible": true,
            "skin": "sknIconWhite120",
            "text": "",
            "textStyle": {},
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblLeftIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLeftIcon"), extendConfig({}, controller.args[2], "lblLeftIcon"));
        flxLeftIcon.add(lblLeftIcon);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite100",
            "text": "Title",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        SimpleHeader.add(flxLeftIcon, lblTitle);
        SimpleHeader.compInstData = {}
        return SimpleHeader;
    }
})
;
define('com/hcl/demo/aggity/SimpleHeader/SimpleHeaderConfig',[],function() {
    return {
        "properties": [{
            "name": "leftIcon",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickLeft"]
    }
});

define("com/hcl/demo/otero/IncidenciasItem/userIncidenciasItemController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/otero/IncidenciasItem/IncidenciasItemControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/otero/IncidenciasItem/IncidenciasItemController", ["com/hcl/demo/otero/IncidenciasItem/userIncidenciasItemController", "com/hcl/demo/otero/IncidenciasItem/IncidenciasItemControllerActions"], function() {
    var controller = require("com/hcl/demo/otero/IncidenciasItem/userIncidenciasItemController");
    var actions = require("com/hcl/demo/otero/IncidenciasItem/IncidenciasItemControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "numIncidencia", function(val) {
            this.view.lblNumIncidencia.text = val;
        });
        defineGetter(this, "numIncidencia", function() {
            return this.view.lblNumIncidencia.text;
        });
        defineSetter(this, "titulo", function(val) {
            this.view.lblTitulo.text = val;
        });
        defineGetter(this, "titulo", function() {
            return this.view.lblTitulo.text;
        });
        defineSetter(this, "observaciones", function(val) {
            this.view.lblObservaciones.text = val;
        });
        defineGetter(this, "observaciones", function() {
            return this.view.lblObservaciones.text;
        });
        defineSetter(this, "causa", function(val) {
            this.view.lblCausa.text = val;
        });
        defineGetter(this, "causa", function() {
            return this.view.lblCausa.text;
        });
        defineSetter(this, "solucionado", function(val) {
            this.view.lblSolucionado.text = val;
        });
        defineGetter(this, "solucionado", function() {
            return this.view.lblSolucionado.text;
        });
        defineSetter(this, "minutos", function(val) {
            this.view.lblMinutos.text = val;
        });
        defineGetter(this, "minutos", function() {
            return this.view.lblMinutos.text;
        });
        defineSetter(this, "fecha", function(val) {
            this.view.lblFecha.text = val;
        });
        defineGetter(this, "fecha", function() {
            return this.view.lblFecha.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/otero/IncidenciasItem/IncidenciasItem',[],function() {
    return function(controller) {
        var IncidenciasItem = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "50dp",
            "id": "IncidenciasItem",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxItemAlternate",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "IncidenciasItem"), extendConfig({}, controller.args[1], "IncidenciasItem"), extendConfig({}, controller.args[2], "IncidenciasItem"));
        IncidenciasItem.setDefaultUnit(voltmx.flex.DP);
        var flxSelectorItemContainer = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxSelectorItemContainer",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "2%",
            "zIndex": 1
        }, controller.args[0], "flxSelectorItemContainer"), extendConfig({}, controller.args[1], "flxSelectorItemContainer"), extendConfig({}, controller.args[2], "flxSelectorItemContainer"));
        flxSelectorItemContainer.setDefaultUnit(voltmx.flex.DP);
        var flxSelectorItem = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "11dp",
            "id": "flxSelectorItem",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "CopyslFbox0if440e67f13f42",
            "width": "11dp",
            "zIndex": 1
        }, controller.args[0], "flxSelectorItem"), extendConfig({}, controller.args[1], "flxSelectorItem"), extendConfig({}, controller.args[2], "flxSelectorItem"));
        flxSelectorItem.setDefaultUnit(voltmx.flex.DP);
        flxSelectorItem.add();
        flxSelectorItemContainer.add(flxSelectorItem);
        var flxNumIncidencia = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxNumIncidencia",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "6%",
            "zIndex": 1
        }, controller.args[0], "flxNumIncidencia"), extendConfig({}, controller.args[1], "flxNumIncidencia"), extendConfig({}, controller.args[2], "flxNumIncidencia"));
        flxNumIncidencia.setDefaultUnit(voltmx.flex.DP);
        var lblNumIncidencia = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblNumIncidencia",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "1",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblNumIncidencia"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblNumIncidencia"), extendConfig({}, controller.args[2], "lblNumIncidencia"));
        flxNumIncidencia.add(lblNumIncidencia);
        var flxIdProyecto = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxIdProyecto",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "5%",
            "zIndex": 1
        }, controller.args[0], "flxIdProyecto"), extendConfig({}, controller.args[1], "flxIdProyecto"), extendConfig({}, controller.args[2], "flxIdProyecto"));
        flxIdProyecto.setDefaultUnit(voltmx.flex.DP);
        var lblIdProyecto = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblIdProyecto",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "2",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblIdProyecto"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblIdProyecto"), extendConfig({}, controller.args[2], "lblIdProyecto"));
        flxIdProyecto.add(lblIdProyecto);
        var flxProyecto = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxProyecto",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "10%",
            "zIndex": 1
        }, controller.args[0], "flxProyecto"), extendConfig({}, controller.args[1], "flxProyecto"), extendConfig({}, controller.args[2], "flxProyecto"));
        flxProyecto.setDefaultUnit(voltmx.flex.DP);
        var lblProyecto = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblProyecto",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "TIENDAS MATARO",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblProyecto"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [5, 0, 5, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblProyecto"), extendConfig({}, controller.args[2], "lblProyecto"));
        flxProyecto.add(lblProyecto);
        var flxSolicitante = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxSolicitante",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "5%",
            "zIndex": 1
        }, controller.args[0], "flxSolicitante"), extendConfig({}, controller.args[1], "flxSolicitante"), extendConfig({}, controller.args[2], "flxSolicitante"));
        flxSolicitante.setDefaultUnit(voltmx.flex.DP);
        var lblSolicitante = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblSolicitante",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "503",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSolicitante"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSolicitante"), extendConfig({}, controller.args[2], "lblSolicitante"));
        flxSolicitante.add(lblSolicitante);
        var flxTipo = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxTipo",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "3%",
            "zIndex": 1
        }, controller.args[0], "flxTipo"), extendConfig({}, controller.args[1], "flxTipo"), extendConfig({}, controller.args[2], "flxTipo"));
        flxTipo.setDefaultUnit(voltmx.flex.DP);
        var lblTipo = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTipo",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "I",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTipo"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTipo"), extendConfig({}, controller.args[2], "lblTipo"));
        flxTipo.add(lblTipo);
        var flxEstado = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxEstado",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "10%",
            "zIndex": 1
        }, controller.args[0], "flxEstado"), extendConfig({}, controller.args[1], "flxEstado"), extendConfig({}, controller.args[2], "flxEstado"));
        flxEstado.setDefaultUnit(voltmx.flex.DP);
        var lblEstado = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "60%",
            "id": "lblEstado",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknEstado",
            "text": "ABIERTA",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblEstado"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [5, 0, 5, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblEstado"), extendConfig({}, controller.args[2], "lblEstado"));
        flxEstado.add(lblEstado);
        var flxTitulo = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxTitulo",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "12%",
            "zIndex": 1
        }, controller.args[0], "flxTitulo"), extendConfig({}, controller.args[1], "flxTitulo"), extendConfig({}, controller.args[2], "flxTitulo"));
        flxTitulo.setDefaultUnit(voltmx.flex.DP);
        var lblTitulo = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitulo",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "Titulo",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitulo"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitulo"), extendConfig({}, controller.args[2], "lblTitulo"));
        flxTitulo.add(lblTitulo);
        var flxObservaciones = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxObservaciones",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "12%",
            "zIndex": 1
        }, controller.args[0], "flxObservaciones"), extendConfig({}, controller.args[1], "flxObservaciones"), extendConfig({}, controller.args[2], "flxObservaciones"));
        flxObservaciones.setDefaultUnit(voltmx.flex.DP);
        var lblObservaciones = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblObservaciones",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "Observaciones",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblObservaciones"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblObservaciones"), extendConfig({}, controller.args[2], "lblObservaciones"));
        flxObservaciones.add(lblObservaciones);
        var flxCausa = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxCausa",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "10%",
            "zIndex": 1
        }, controller.args[0], "flxCausa"), extendConfig({}, controller.args[1], "flxCausa"), extendConfig({}, controller.args[2], "flxCausa"));
        flxCausa.setDefaultUnit(voltmx.flex.DP);
        var lblCausa = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblCausa",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "Causa",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblCausa"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCausa"), extendConfig({}, controller.args[2], "lblCausa"));
        flxCausa.add(lblCausa);
        var flxSolucionado = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxSolucionado",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "6%",
            "zIndex": 1
        }, controller.args[0], "flxSolucionado"), extendConfig({}, controller.args[1], "flxSolucionado"), extendConfig({}, controller.args[2], "flxSolucionado"));
        flxSolucionado.setDefaultUnit(voltmx.flex.DP);
        var lblSolucionado = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblSolucionado",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "S",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSolucionado"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSolucionado"), extendConfig({}, controller.args[2], "lblSolucionado"));
        flxSolucionado.add(lblSolucionado);
        var flxMinutos = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxMinutos",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "12%",
            "zIndex": 1
        }, controller.args[0], "flxMinutos"), extendConfig({}, controller.args[1], "flxMinutos"), extendConfig({}, controller.args[2], "flxMinutos"));
        flxMinutos.setDefaultUnit(voltmx.flex.DP);
        var lblMinutos = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblMinutos",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "Minutos",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblMinutos"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblMinutos"), extendConfig({}, controller.args[2], "lblMinutos"));
        flxMinutos.add(lblMinutos);
        var flxFecha = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxFecha",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "12%",
            "zIndex": 1
        }, controller.args[0], "flxFecha"), extendConfig({}, controller.args[1], "flxFecha"), extendConfig({}, controller.args[2], "flxFecha"));
        flxFecha.setDefaultUnit(voltmx.flex.DP);
        var lblFecha = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblFecha",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblDarkGrey80",
            "text": "04/03/2022",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblFecha"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblFecha"), extendConfig({}, controller.args[2], "lblFecha"));
        flxFecha.add(lblFecha);
        IncidenciasItem.add(flxSelectorItemContainer, flxNumIncidencia, flxIdProyecto, flxProyecto, flxSolicitante, flxTipo, flxEstado, flxTitulo, flxObservaciones, flxCausa, flxSolucionado, flxMinutos, flxFecha);
        IncidenciasItem.compInstData = {}
        return IncidenciasItem;
    }
})
;
define('com/hcl/demo/otero/IncidenciasItem/IncidenciasItemConfig',[],function() {
    return {
        "properties": [{
            "name": "numIncidencia",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "titulo",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "observaciones",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "causa",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "solucionado",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "minutos",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "fecha",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/otero/LabelHeader/userLabelHeaderController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/otero/LabelHeader/LabelHeaderControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/otero/LabelHeader/LabelHeaderController", ["com/hcl/demo/otero/LabelHeader/userLabelHeaderController", "com/hcl/demo/otero/LabelHeader/LabelHeaderControllerActions"], function() {
    var controller = require("com/hcl/demo/otero/LabelHeader/userLabelHeaderController");
    var actions = require("com/hcl/demo/otero/LabelHeader/LabelHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/otero/LabelHeader/LabelHeader',[],function() {
    return function(controller) {
        var LabelHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "LabelHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "6%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "LabelHeader"), extendConfig({}, controller.args[1], "LabelHeader"), extendConfig({}, controller.args[2], "LabelHeader"));
        LabelHeader.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0f9a12733eaba4e",
            "text": "N. incidencia",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        LabelHeader.add(lblTitle);
        LabelHeader.compInstData = {}
        return LabelHeader;
    }
})
;
define('com/hcl/demo/otero/LabelHeader/LabelHeaderConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/otero/LabelHeaderSort/userLabelHeaderSortController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            eventManager.subscribe('evt_sort', ({
                key,
                newSortOrder
            }) => {
                this.sortOrder = key === this.key ? newSortOrder : 'none';
            });
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.onClick = () => {
                        let newSortOrder = 'asc';
                        this.sortOrder === 'asc' && (newSortOrder = 'desc');
                        eventManager.publish('evt_sort', {
                            key: this.key,
                            newSortOrder
                        });
                    };
                    this.initDone = true;
                }
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, 'sortOrder', () => {
                return this._sortOrder;
            });
            defineSetter(this, 'sortOrder', value => {
                this._sortOrder = value;
                this.view.lblIconUp.isVisible = value === 'asc';
                this.view.lblIconDown.isVisible = value === 'desc';
            });
            defineGetter(this, 'key', () => {
                return this._key;
            });
            defineSetter(this, 'key', value => {
                this._key = value;
            });
        }
    };
});
define("com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSortControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSortController", ["com/hcl/demo/otero/LabelHeaderSort/userLabelHeaderSortController", "com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSortControllerActions"], function() {
    var controller = require("com/hcl/demo/otero/LabelHeaderSort/userLabelHeaderSortController");
    var actions = require("com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSortControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSort',[],function() {
    return function(controller) {
        var LabelHeaderSort = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "LabelHeaderSort",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "6%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "LabelHeaderSort"), extendConfig({}, controller.args[1], "LabelHeaderSort"), extendConfig({}, controller.args[2], "LabelHeaderSort"));
        LabelHeaderSort.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopydefLabel0f9a12733eaba4e",
            "text": "N. incidencia",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblIconUp = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblIconUp",
            "isVisible": false,
            "right": "5dp",
            "skin": "sknLblIconWhite70",
            "text": "",
            "top": "0dp",
            "width": "10dp",
            "zIndex": 1
        }, controller.args[0], "lblIconUp"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblIconUp"), extendConfig({}, controller.args[2], "lblIconUp"));
        var lblIconDown = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblIconDown",
            "isVisible": false,
            "right": "5dp",
            "skin": "sknLblIconWhite70",
            "text": "",
            "top": "0dp",
            "width": "10dp",
            "zIndex": 1
        }, controller.args[0], "lblIconDown"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblIconDown"), extendConfig({}, controller.args[2], "lblIconDown"));
        LabelHeaderSort.add(lblTitle, lblIconUp, lblIconDown);
        LabelHeaderSort.compInstData = {}
        return LabelHeaderSort;
    }
})
;
define('com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSortConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sortOrder",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "key",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("comhcl/demo/aggity/HemburgerMenuItem/userHemburgerMenuItemController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.onClick = () => this.onSelected(this.key);
                    this.initDone = true;
                }
            };
        },
        initGettersSetters: function() {},
        onSelected() {}
    };
});
define("comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItemControllerActions", {
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
});
define("comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItemController", ["comhcl/demo/aggity/HemburgerMenuItem/userHemburgerMenuItemController", "comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItemControllerActions"], function() {
    var controller = require("comhcl/demo/aggity/HemburgerMenuItem/userHemburgerMenuItemController");
    var actions = require("comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItemControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "icon", function(val) {
            this.view.lblLeftIcon.text = val;
        });
        defineGetter(this, "icon", function() {
            return this.view.lblLeftIcon.text;
        });
        defineSetter(this, "key", function(val) {
            this.view.key.text = val;
        });
        defineGetter(this, "key", function() {
            return this.view.key.text;
        });
        defineSetter(this, "item", function(val) {
            this.view.item.text = val;
        });
        defineGetter(this, "item", function() {
            return this.view.item.text;
        });
        defineSetter(this, "description", function(val) {
            this.view.description.text = val;
        });
        defineGetter(this, "description", function() {
            return this.view.description.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItem',[],function() {
    return function(controller) {
        var HemburgerMenuItem = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "60dp",
            "id": "HemburgerMenuItem",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "HemburgerMenuItem"), extendConfig({}, controller.args[1], "HemburgerMenuItem"), extendConfig({}, controller.args[2], "HemburgerMenuItem"));
        HemburgerMenuItem.setDefaultUnit(voltmx.flex.DP);
        var flxFirstRow = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxFirstRow",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxFirstRow"), extendConfig({}, controller.args[1], "flxFirstRow"), extendConfig({}, controller.args[2], "flxFirstRow"));
        flxFirstRow.setDefaultUnit(voltmx.flex.DP);
        var flxLeftIcon = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxLeftIcon",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0%",
            "width": "50dp",
            "zIndex": 1
        }, controller.args[0], "flxLeftIcon"), extendConfig({}, controller.args[1], "flxLeftIcon"), extendConfig({}, controller.args[2], "flxLeftIcon"));
        flxLeftIcon.setDefaultUnit(voltmx.flex.DP);
        var lblLeftIcon = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblLeftIcon",
            "isVisible": true,
            "skin": "sknIconDarkGrey120",
            "text": "",
            "textStyle": {},
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblLeftIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLeftIcon"), extendConfig({}, controller.args[2], "lblLeftIcon"));
        flxLeftIcon.add(lblLeftIcon);
        var key = new voltmx.ui.Label(extendConfig({
            "id": "key",
            "isVisible": false,
            "left": "148dp",
            "skin": "defLabel",
            "textStyle": {},
            "top": "20dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "key"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "key"), extendConfig({}, controller.args[2], "key"));
        var item = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "item",
            "isVisible": true,
            "left": "50dp",
            "skin": "sknLblDarkGrey120",
            "text": "Item",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "item"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "item"), extendConfig({}, controller.args[2], "item"));
        flxFirstRow.add(flxLeftIcon, key, item);
        var flxSecondRow = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20dp",
            "id": "flxSecondRow",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxSecondRow"), extendConfig({}, controller.args[1], "flxSecondRow"), extendConfig({}, controller.args[2], "flxSecondRow"));
        flxSecondRow.setDefaultUnit(voltmx.flex.DP);
        var description = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "description",
            "isVisible": true,
            "left": "50dp",
            "skin": "sknLblDarkGrey90",
            "text": "Description",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "description"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "description"), extendConfig({}, controller.args[2], "description"));
        flxSecondRow.add(description);
        HemburgerMenuItem.add(flxFirstRow, flxSecondRow);
        HemburgerMenuItem.compInstData = {}
        return HemburgerMenuItem;
    }
})
;
define('comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItemConfig',[],function() {
    return {
        "properties": [{
            "name": "icon",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "key",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "item",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "description",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onSelected"]
    }
});

define("com/hcl/demo/aggity/HamburgerMenu/userHamburgerMenuController", [],function() {
    const MENU_LEFT = -300;
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.onInit();
                    this.initDone = true;
                }
                this.onPreShow();
            };
        },
        onInit() {
            this.view.flxBackground.onClick = () => this.toggle(false);
            this.view.menuHeader.onClickLeft = () => {
                this.toggle(false);
            };
            this.view.flxMenuItems.widgets().forEach((menuItem) => {
                menuItem.onSelected = (key) => {
                    this.toggle(false, true);
                    this.onItemSelected(key);
                };
            });
        },
        onPreShow() {},
        initGettersSetters() {},
        toggle(open, skipAnimation) {
            if (skipAnimation) {
                this.view.isVisible = open;
                this.view.flxBackground.isVisible = open;
                this.view.flxMenu.left = open ? 0 : MENU_LEFT;
            } else {
                const self = this;
                open && (self.view.isVisible = true);
                this.view.flxMenu.animate(voltmx.ui.createAnimation({
                    "0": {
                        left: open ? MENU_LEFT : 0
                    },
                    "100": {
                        left: open ? 0 : MENU_LEFT
                    }
                }), {
                    "duration": 0.5,
                    "iterationCount": 1,
                    "delay": 0,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS
                }, {
                    animationStart: function() {
                        open && (self.view.flxBackground.isVisible = true);
                    },
                    animationEnd: function() {
                        open || (self.view.isVisible = false);
                        open || (self.view.flxBackground.isVisible = false);
                    }
                });
            }
        },
        onItemSelected(key) {
            voltmx.print(`Selected menu item ${key}`);
        }
    };
});
define("com/hcl/demo/aggity/HamburgerMenu/HamburgerMenuControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/aggity/HamburgerMenu/HamburgerMenuController", ["com/hcl/demo/aggity/HamburgerMenu/userHamburgerMenuController", "com/hcl/demo/aggity/HamburgerMenu/HamburgerMenuControllerActions"], function() {
    var controller = require("com/hcl/demo/aggity/HamburgerMenu/userHamburgerMenuController");
    var actions = require("com/hcl/demo/aggity/HamburgerMenu/HamburgerMenuControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/aggity/HamburgerMenu/HamburgerMenu',[],function() {
    return function(controller) {
        var HamburgerMenu = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "HamburgerMenu",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "HamburgerMenu"), extendConfig({}, controller.args[1], "HamburgerMenu"), extendConfig({}, controller.args[2], "HamburgerMenu"));
        HamburgerMenu.setDefaultUnit(voltmx.flex.DP);
        var flxBackground = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxBackground",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopysknFlxBackground1",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxBackground"), extendConfig({}, controller.args[1], "flxBackground"), extendConfig({}, controller.args[2], "flxBackground"));
        flxBackground.setDefaultUnit(voltmx.flex.DP);
        flxBackground.add();
        var flxMenu = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopysknFlxWhite1",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1
        }, controller.args[0], "flxMenu"), extendConfig({}, controller.args[1], "flxMenu"), extendConfig({}, controller.args[2], "flxMenu"));
        flxMenu.setDefaultUnit(voltmx.flex.DP);
        var menuHeader = new com.hcl.demo.aggity.SimpleHeader(extendConfig({
            "height": "7%",
            "id": "menuHeader",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "sknFlxBlack",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "lblLeftIcon": {
                    "text": ""
                },
                "lblTitle": {
                    "text": "Opciones"
                },
                "SimpleHeader": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "menuHeader"), extendConfig({
            "overrides": {}
        }, controller.args[1], "menuHeader"), extendConfig({
            "overrides": {}
        }, controller.args[2], "menuHeader"));
        var flxMenuItems = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "93%",
            "id": "flxMenuItems",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxMenuItems"), extendConfig({}, controller.args[1], "flxMenuItems"), extendConfig({}, controller.args[2], "flxMenuItems"));
        flxMenuItems.setDefaultUnit(voltmx.flex.DP);
        var itemInicio = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemInicio",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Pantalla Principal"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Inicio"
                },
                "key": {
                    "text": "inicio"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemInicio"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemInicio"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemInicio"));
        var itemTrabajo = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemTrabajo",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Parte trabajo"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "P. trabajo"
                },
                "key": {
                    "text": "trabajo"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemTrabajo"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemTrabajo"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemTrabajo"));
        var itemDieta = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemDieta",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Parte dieta"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "P. dieta"
                },
                "key": {
                    "text": "dieta"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemDieta"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemDieta"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemDieta"));
        var itemFirmar = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemFirmar",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Firmar partes en lote"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Fir. partes"
                },
                "key": {
                    "text": "firmar"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemFirmar"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemFirmar"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemFirmar"));
        var itemIncidencias = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemIncidencias",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Incidencias"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Incidencias"
                },
                "key": {
                    "text": "incidencias"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemIncidencias"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemIncidencias"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemIncidencias"));
        var itemInformes = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemInformes",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Informes"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Informes"
                },
                "key": {
                    "text": "informes"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemInformes"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemInformes"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemInformes"));
        var itemRepasos = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemRepasos",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Repasos"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Repasos"
                },
                "key": {
                    "text": "repasos"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemRepasos"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemRepasos"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemRepasos"));
        var itemProyectos = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemProyectos",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Proyectos"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Proyectos"
                },
                "key": {
                    "text": "proyectos"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemProyectos"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemProyectos"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemProyectos"));
        var itemSincronizar = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemSincronizar",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Sincoronizar"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Suncronizar"
                },
                "key": {
                    "text": "sincornizar"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemSincronizar"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemSincronizar"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemSincronizar"));
        var itemChat = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemChat",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Abrir chat"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Chat"
                },
                "key": {
                    "text": "chat"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemChat"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemChat"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemChat"));
        var itemDesconectar = new comhcl.demo.aggity.HemburgerMenuItem(extendConfig({
            "height": "60dp",
            "id": "itemDesconectar",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "overrides": {
                "description": {
                    "text": "Desconectar"
                },
                "lblLeftIcon": {
                    "text": ""
                },
                "item": {
                    "text": "Desconectar"
                },
                "key": {
                    "text": "desconectar"
                },
                "HemburgerMenuItem": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "itemDesconectar"), extendConfig({
            "overrides": {}
        }, controller.args[1], "itemDesconectar"), extendConfig({
            "overrides": {}
        }, controller.args[2], "itemDesconectar"));
        flxMenuItems.add(itemInicio, itemTrabajo, itemDieta, itemFirmar, itemIncidencias, itemInformes, itemRepasos, itemProyectos, itemSincronizar, itemChat, itemDesconectar);
        flxMenu.add(menuHeader, flxMenuItems);
        HamburgerMenu.add(flxBackground, flxMenu);
        HamburgerMenu.compInstData = {
            "menuHeader": {
                "leftIcon": "",
                "title": "Opciones",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemInicio": {
                "description": "Pantalla Principal",
                "icon": "",
                "item": "Inicio",
                "key": "inicio",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemTrabajo": {
                "description": "Parte trabajo",
                "icon": "",
                "item": "P. trabajo",
                "key": "trabajo",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemDieta": {
                "description": "Parte dieta",
                "icon": "",
                "item": "P. dieta",
                "key": "dieta",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemFirmar": {
                "description": "Firmar partes en lote",
                "icon": "",
                "item": "Fir. partes",
                "key": "firmar",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemIncidencias": {
                "description": "Incidencias",
                "icon": "",
                "item": "Incidencias",
                "key": "incidencias",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemInformes": {
                "description": "Informes",
                "icon": "",
                "item": "Informes",
                "key": "informes",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemRepasos": {
                "description": "Repasos",
                "icon": "",
                "item": "Repasos",
                "key": "repasos",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemProyectos": {
                "description": "Proyectos",
                "icon": "",
                "item": "Proyectos",
                "key": "proyectos",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemSincronizar": {
                "description": "Sincoronizar",
                "icon": "",
                "item": "Suncronizar",
                "key": "sincornizar",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemChat": {
                "description": "Abrir chat",
                "icon": "",
                "item": "Chat",
                "key": "chat",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "itemDesconectar": {
                "description": "Desconectar",
                "icon": "",
                "item": "Desconectar",
                "key": "desconectar",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            }
        }
        return HamburgerMenu;
    }
})
;
define('com/hcl/demo/aggity/HamburgerMenu/HamburgerMenuConfig',[],function() {
    return {
        "properties": [],
        "apis": ["toggle"],
        "events": ["onItemSelected"]
    }
});

require(['applicationController','com/hcl/demo/aggity/CheckboxField/CheckboxFieldController','com/hcl/demo/aggity/CheckboxField/CheckboxField','com/hcl/demo/aggity/CheckboxField/CheckboxFieldConfig','com/hcl/demo/aggity/DateField/DateFieldController','com/hcl/demo/aggity/DateField/DateField','com/hcl/demo/aggity/DateField/DateFieldConfig','com/hcl/demo/aggity/EditField/EditFieldController','com/hcl/demo/aggity/EditField/EditField','com/hcl/demo/aggity/EditField/EditFieldConfig','com/hcl/demo/aggity/HomePageButton/HomePageButtonController','com/hcl/demo/aggity/HomePageButton/HomePageButton','com/hcl/demo/aggity/HomePageButton/HomePageButtonConfig','com/hcl/demo/aggity/SimpleHeader/SimpleHeaderController','com/hcl/demo/aggity/SimpleHeader/SimpleHeader','com/hcl/demo/aggity/SimpleHeader/SimpleHeaderConfig','com/hcl/demo/otero/IncidenciasItem/IncidenciasItemController','com/hcl/demo/otero/IncidenciasItem/IncidenciasItem','com/hcl/demo/otero/IncidenciasItem/IncidenciasItemConfig','com/hcl/demo/otero/LabelHeader/LabelHeaderController','com/hcl/demo/otero/LabelHeader/LabelHeader','com/hcl/demo/otero/LabelHeader/LabelHeaderConfig','com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSortController','com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSort','com/hcl/demo/otero/LabelHeaderSort/LabelHeaderSortConfig','comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItemController','comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItem','comhcl/demo/aggity/HemburgerMenuItem/HemburgerMenuItemConfig','com/hcl/demo/aggity/HamburgerMenu/HamburgerMenuController','com/hcl/demo/aggity/HamburgerMenu/HamburgerMenu','com/hcl/demo/aggity/HamburgerMenu/HamburgerMenuConfig'], function(){});

define("sparequirefileslist", function(){});

