define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(voltmx.flex.DP);
            var flxHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxHeader",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {}, {});
            flxHeader.setDefaultUnit(voltmx.flex.DP);
            var imgLogo = new voltmx.ui.Image2({
                "height": "70dp",
                "id": "imgLogo",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "logo_martinez_otero.png",
                "top": "0dp",
                "width": "290dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgLogo);
            var flxShadow = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10dp",
                "id": "flxShadow",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxShadow",
                "top": "68dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxShadow.setDefaultUnit(voltmx.flex.DP);
            flxShadow.add();
            var flxMenu = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "500dp",
                "id": "flxMenu",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "78dp",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            flxMenu.setDefaultUnit(voltmx.flex.DP);
            var flxMenuItems = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMenuItems",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMenuItems.setDefaultUnit(voltmx.flex.DP);
            var flxObras = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxObras",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxObras.setDefaultUnit(voltmx.flex.DP);
            var flxIconObras = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxIconObras",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "44dp",
                "zIndex": 1
            }, {}, {});
            flxIconObras.setDefaultUnit(voltmx.flex.DP);
            var lblIconFolderClose = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblIconFolderClose",
                "isVisible": false,
                "skin": "sknIconGrey120",
                "text": "",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIconFolderOpen = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "lblIconFolderOpen",
                "isVisible": true,
                "skin": "sknIconGrey120",
                "text": "",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIconObras.add(lblIconFolderClose, lblIconFolderOpen);
            var lblObras = new voltmx.ui.Label({
                "height": "44dp",
                "id": "lblObras",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknLabelMenuItem",
                "text": "Obras",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxIconOpenClose = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxIconOpenClose",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "right": 10,
                "skin": "slFbox",
                "top": "0dp",
                "width": "44dp",
                "zIndex": 1
            }, {}, {});
            flxIconOpenClose.setDefaultUnit(voltmx.flex.DP);
            var lblIconMinus = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "lblIconMinus",
                "isVisible": true,
                "skin": "sknIconGrey80",
                "text": "",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIconPlus = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "lblIconPlus",
                "isVisible": false,
                "skin": "sknIconGrey80",
                "text": "+",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIconOpenClose.add(lblIconMinus, lblIconPlus);
            flxObras.add(flxIconObras, lblObras, flxIconOpenClose);
            var flxMenuDivider1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxMenuDivider1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMenuDivider",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMenuDivider1.setDefaultUnit(voltmx.flex.DP);
            flxMenuDivider1.add();
            var flxObrasItems = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "135dp",
                "id": "flxObrasItems",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxObrasItems.setDefaultUnit(voltmx.flex.DP);
            var flxItemProyectos = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxItemProyectos",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxItemProyectos.setDefaultUnit(voltmx.flex.DP);
            var lblItemProyectos = new voltmx.ui.Label({
                "height": "44dp",
                "id": "lblItemProyectos",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknLabelMenuItem",
                "text": "Proyectos",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxItemProyectos.add(lblItemProyectos);
            var flxMenuDivider2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxMenuDivider2",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMenuDivider",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMenuDivider2.setDefaultUnit(voltmx.flex.DP);
            flxMenuDivider2.add();
            var flxItemIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxItemIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMenuItemSelected",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxItemIncidencias.setDefaultUnit(voltmx.flex.DP);
            var lblItemIncidencias = new voltmx.ui.Label({
                "height": "44dp",
                "id": "lblItemIncidencias",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknLabelMenuItem",
                "text": "Incidencias",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxItemIncidencias.add(lblItemIncidencias);
            var flxMenuDivider3 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxMenuDivider3",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMenuDivider",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMenuDivider3.setDefaultUnit(voltmx.flex.DP);
            flxMenuDivider3.add();
            var flxItemIncidenciasHist = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxItemIncidenciasHist",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxItemIncidenciasHist.setDefaultUnit(voltmx.flex.DP);
            var lblIncidenciasHist = new voltmx.ui.Label({
                "height": "44dp",
                "id": "lblIncidenciasHist",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknLabelMenuItem",
                "text": "Incidencias Histórico",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxItemIncidenciasHist.add(lblIncidenciasHist);
            var flxMenuDivider4 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxMenuDivider4",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMenuDivider",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMenuDivider4.setDefaultUnit(voltmx.flex.DP);
            flxMenuDivider4.add();
            flxObrasItems.add(flxItemProyectos, flxMenuDivider2, flxItemIncidencias, flxMenuDivider3, flxItemIncidenciasHist, flxMenuDivider4);
            var flxAyudas = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxAyudas",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxAyudas.setDefaultUnit(voltmx.flex.DP);
            var flxFolderAyudas = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "44dp",
                "id": "flxFolderAyudas",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "44dp",
                "zIndex": 1
            }, {}, {});
            flxFolderAyudas.setDefaultUnit(voltmx.flex.DP);
            var lblIconFolderAyudas = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "lblIconFolderAyudas",
                "isVisible": true,
                "skin": "sknIconGrey120",
                "text": "",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFolderAyudas.add(lblIconFolderAyudas);
            var lblAyudas = new voltmx.ui.Label({
                "height": "44dp",
                "id": "lblAyudas",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknLabelMenuItem",
                "text": "Ayudas",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAyudas.add(flxFolderAyudas, lblAyudas);
            var flxMenuDivider5 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxMenuDivider5",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMenuDivider",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMenuDivider5.setDefaultUnit(voltmx.flex.DP);
            flxMenuDivider5.add();
            flxMenuItems.add(flxObras, flxMenuDivider1, flxObrasItems, flxAyudas, flxMenuDivider5);
            flxMenu.add(flxMenuItems);
            var flxShadowMenu = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxShadowMenu",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "290dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "sknFlxShadowMenu",
                "top": "73dp",
                "width": "10dp",
                "zIndex": 1
            }, {}, {});
            flxShadowMenu.setDefaultUnit(voltmx.flex.DP);
            flxShadowMenu.add();
            var flxUser = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxUser",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDarkGrey",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            flxUser.setDefaultUnit(voltmx.flex.DP);
            var lblUsername = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblUsername",
                "isVisible": true,
                "right": "0dp",
                "skin": "CopydefLabel0adbfbf5884b043",
                "text": "Albert Oller (project manager)",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 5, 0],
                "paddingInPixel": false
            }, {});
            var lblIconUser = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblIconUser",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey250",
                "text": "",
                "top": "0dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUser.add(lblUsername, lblIconUser);
            var flxContent = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "90%",
                "horizontalScrollIndicator": true,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "300dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_BOTH,
                "skin": "slFSbox",
                "top": "73dp",
                "verticalScrollIndicator": true,
                "width": "90%",
                "zIndex": 1
            }, {}, {});
            flxContent.setDefaultUnit(voltmx.flex.DP);
            var flxProyectos = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxProyectos",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxProyectos.setDefaultUnit(voltmx.flex.DP);
            var flxTitleProyectos = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "5%",
                "id": "flxTitleProyectos",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDarkGrey",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxTitleProyectos.setDefaultUnit(voltmx.flex.DP);
            var lblTitleProyectos = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblTitleProyectos",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0h67304bcb05d4b",
                "text": "Proyectos Project Manager",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitleProyectos.add(lblTitleProyectos);
            flxProyectos.add(flxTitleProyectos);
            var flxIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0.00%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxIncidencias.setDefaultUnit(voltmx.flex.DP);
            var flxTitleIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "5%",
                "id": "flxTitleIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDarkGrey",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxTitleIncidencias.setDefaultUnit(voltmx.flex.DP);
            var lblTitleIncidencias = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblTitleIncidencias",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0h67304bcb05d4b",
                "text": "Incidencias Project Manager",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitleIncidencias.add(lblTitleIncidencias);
            var flxToolbarIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxToolbarIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxToolbar",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxToolbarIncidencias.setDefaultUnit(voltmx.flex.DP);
            var flxButtonsToolbarIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxButtonsToolbarIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "600dp"
            }, {}, {});
            flxButtonsToolbarIncidencias.setDefaultUnit(voltmx.flex.DP);
            var lblToolbarReload = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbarReload",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar2 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "+",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar3 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar3",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar4 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar4",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar5 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar5",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar6 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar6",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar7 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar7",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar8 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar8",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar9 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar9",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblToolbar10 = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblToolbar10",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey150",
                "text": "",
                "width": "60dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtonsToolbarIncidencias.add(lblToolbarReload, lblToolbar2, lblToolbar3, lblToolbar4, lblToolbar5, lblToolbar6, lblToolbar7, lblToolbar8, lblToolbar9, lblToolbar10);
            var flxPaginationIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPaginationIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1
            }, {}, {});
            flxPaginationIncidencias.setDefaultUnit(voltmx.flex.DP);
            var lblIconTop = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "30dp",
                "id": "lblIconTop",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey100",
                "text": "",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIconLeft = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "30dp",
                "id": "lblIconLeft",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey100",
                "text": "",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPages = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "60dp",
                "id": "lblPages",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDarkGrey80",
                "text": "Pág. 1 de 1",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIconRight = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "30dp",
                "id": "lblIconRight",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey100",
                "text": "",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIconBottom = new voltmx.ui.Label({
                "centerY": "50%",
                "height": "30dp",
                "id": "lblIconBottom",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknIconGrey100",
                "text": "",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaginationIncidencias.add(lblIconTop, lblIconLeft, lblPages, lblIconRight, lblIconBottom);
            flxToolbarIncidencias.add(flxButtonsToolbarIncidencias, flxPaginationIncidencias);
            var flxSearchIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "flxSearchIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSearchIncidencias.setDefaultUnit(voltmx.flex.DP);
            var flxSearchIncidencias1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchIncidencias1",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "80dp",
                "zIndex": 1
            }, {}, {});
            flxSearchIncidencias1.setDefaultUnit(voltmx.flex.DP);
            var lblLabelProyecto = new voltmx.ui.Label({
                "height": "50%",
                "id": "lblLabelProyecto",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDarkGrey80",
                "text": "Proyecto: ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLabelTitulo = new voltmx.ui.Label({
                "height": "50%",
                "id": "lblLabelTitulo",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDarkGrey80",
                "text": "Titulo: ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIncidencias1.add(lblLabelProyecto, lblLabelTitulo);
            var flxSearchIncidencias2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchIncidencias2",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            flxSearchIncidencias2.setDefaultUnit(voltmx.flex.DP);
            var lbSearchProyecto = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40%",
                "id": "lbSearchProyecto",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbSearchArea",
                "top": "5%",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var txtSearchTitulo = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "5%",
                "centerY": "75%",
                "focusSkin": "defTextBoxFocus",
                "height": "40%",
                "id": "txtSearchTitulo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "sknTxtSearchArea",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxSearchIncidencias2.add(lbSearchProyecto, txtSearchTitulo);
            var flxSearchIncidencias3 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchIncidencias3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "120dp",
                "zIndex": 1
            }, {}, {});
            flxSearchIncidencias3.setDefaultUnit(voltmx.flex.DP);
            var lblLabelSolicitante = new voltmx.ui.Label({
                "height": "50%",
                "id": "lblLabelSolicitante",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDarkGrey80",
                "text": "Solicitante: ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLabelNombre = new voltmx.ui.Label({
                "height": "50%",
                "id": "lblLabelNombre",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDarkGrey80",
                "text": "Nombre asignado: ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIncidencias3.add(lblLabelSolicitante, lblLabelNombre);
            var flxSearchIncidencias4 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchIncidencias4",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1
            }, {}, {});
            flxSearchIncidencias4.setDefaultUnit(voltmx.flex.DP);
            var lbSearchSolicitante = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40%",
                "id": "lbSearchSolicitante",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbSearchArea",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lbSearchNombre = new voltmx.ui.ListBox({
                "bottom": "5%",
                "focusSkin": "defListBoxFocus",
                "height": "40%",
                "id": "lbSearchNombre",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbSearchArea",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxSearchIncidencias4.add(lbSearchSolicitante, lbSearchNombre);
            var flxSearchIncidencias5 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchIncidencias5",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 1
            }, {}, {});
            flxSearchIncidencias5.setDefaultUnit(voltmx.flex.DP);
            var lblLabelDepartamento = new voltmx.ui.Label({
                "height": "50%",
                "id": "lblLabelDepartamento",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDarkGrey80",
                "text": "Departamento: ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLabelTipo = new voltmx.ui.Label({
                "height": "50%",
                "id": "lblLabelTipo",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDarkGrey80",
                "text": "Tipo: ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIncidencias5.add(lblLabelDepartamento, lblLabelTipo);
            var flxSearchIncidencias6 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchIncidencias6",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1
            }, {}, {});
            flxSearchIncidencias6.setDefaultUnit(voltmx.flex.DP);
            var lbSearchDepartamento = new voltmx.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40%",
                "id": "lbSearchDepartamento",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbSearchArea",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var txtSearchTipo = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "5%",
                "centerY": "75%",
                "focusSkin": "defTextBoxFocus",
                "height": "40%",
                "id": "txtSearchTipo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "skin": "sknTxtSearchArea",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "30%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxSearchIncidencias6.add(lbSearchDepartamento, txtSearchTipo);
            flxSearchIncidencias.add(flxSearchIncidencias1, flxSearchIncidencias2, flxSearchIncidencias3, flxSearchIncidencias4, flxSearchIncidencias5, flxSearchIncidencias6);
            var flxHeaderIncidencias = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "4%",
                "id": "flxHeaderIncidencias",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0b952feb1d22e47",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxHeaderIncidencias.setDefaultUnit(voltmx.flex.DP);
            var flxHeaderIncidencias1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxHeaderIncidencias1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "2%",
                "zIndex": 1
            }, {}, {});
            flxHeaderIncidencias1.setDefaultUnit(voltmx.flex.DP);
            var flxSelectorHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "11dp",
                "id": "flxSelectorHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "CopyslFbox0if440e67f13f42",
                "width": "11dp",
                "zIndex": 1
            }, {}, {});
            flxSelectorHeader.setDefaultUnit(voltmx.flex.DP);
            flxSelectorHeader.add();
            flxHeaderIncidencias1.add(flxSelectorHeader);
            var headerIncidencia = new com.hcl.demo.otero.LabelHeaderSort({
                "height": "100%",
                "id": "headerIncidencia",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "6%",
                "zIndex": 1,
                "overrides": {
                    "LabelHeaderSort": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headerIncidencia.sortOrder = "asc";
            headerIncidencia.key = "id";
            var headerIdProyecto = new com.hcl.demo.otero.LabelHeader({
                "height": "100%",
                "id": "headerIdProyecto",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "5%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Id proyecto"
                    },
                    "LabelHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var headerProyecto = new com.hcl.demo.otero.LabelHeader({
                "height": "100%",
                "id": "headerProyecto",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Proyecto"
                    },
                    "LabelHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var headerSolicitante = new com.hcl.demo.otero.LabelHeader({
                "height": "100%",
                "id": "headerSolicitante",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "5%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Solicitante"
                    },
                    "LabelHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var headerTipo = new com.hcl.demo.otero.LabelHeader({
                "height": "100%",
                "id": "headerTipo",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "3%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Tipo"
                    },
                    "LabelHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var headerEstado = new com.hcl.demo.otero.LabelHeader({
                "height": "100%",
                "id": "headerEstado",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Estado"
                    },
                    "LabelHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var headerTitulo = new com.hcl.demo.otero.LabelHeaderSort({
                "height": "100%",
                "id": "headerTitulo",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "12%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Titulo"
                    },
                    "LabelHeaderSort": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headerTitulo.sortOrder = "none";
            headerTitulo.key = "titulo";
            var headerObservaciones = new com.hcl.demo.otero.LabelHeaderSort({
                "height": "100%",
                "id": "headerObservaciones",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "12%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Observaciones"
                    },
                    "LabelHeaderSort": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headerObservaciones.sortOrder = "none";
            headerObservaciones.key = "observaciones";
            var headerCausa = new com.hcl.demo.otero.LabelHeaderSort({
                "height": "100%",
                "id": "headerCausa",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Causa"
                    },
                    "LabelHeaderSort": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headerCausa.sortOrder = "none";
            headerCausa.key = "causa";
            var headerSolucionado = new com.hcl.demo.otero.LabelHeaderSort({
                "height": "100%",
                "id": "headerSolucionado",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "6%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Solucionado"
                    },
                    "LabelHeaderSort": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headerSolucionado.sortOrder = "none";
            headerSolucionado.key = "solucionado";
            var headerMinutos = new com.hcl.demo.otero.LabelHeaderSort({
                "height": "100%",
                "id": "headerMinutos",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "12%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Minutos"
                    },
                    "LabelHeaderSort": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headerMinutos.sortOrder = "none";
            headerMinutos.key = "minutos";
            var headerFecha = new com.hcl.demo.otero.LabelHeaderSort({
                "height": "100%",
                "id": "headerFecha",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "7%",
                "zIndex": 1,
                "overrides": {
                    "lblTitle": {
                        "text": "Fecha"
                    },
                    "LabelHeaderSort": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headerFecha.sortOrder = "none";
            headerFecha.key = "fecha";
            flxHeaderIncidencias.add(flxHeaderIncidencias1, headerIncidencia, headerIdProyecto, headerProyecto, headerSolicitante, headerTipo, headerEstado, headerTitulo, headerObservaciones, headerCausa, headerSolucionado, headerMinutos, headerFecha);
            var flxIncidenciasItems = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "76%",
                "horizontalScrollIndicator": true,
                "id": "flxIncidenciasItems",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "sknFlsWhite",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxIncidenciasItems.setDefaultUnit(voltmx.flex.DP);
            flxIncidenciasItems.add();
            flxIncidencias.add(flxTitleIncidencias, flxToolbarIncidencias, flxSearchIncidencias, flxHeaderIncidencias, flxIncidenciasItems);
            var flxIncidenciasHist = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxIncidenciasHist",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxIncidenciasHist.setDefaultUnit(voltmx.flex.DP);
            var flxTitelIncidenciasHist = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "5%",
                "id": "flxTitelIncidenciasHist",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDarkGrey",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxTitelIncidenciasHist.setDefaultUnit(voltmx.flex.DP);
            var lblTitleIncidenciasHist = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblTitleIncidenciasHist",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0h67304bcb05d4b",
                "text": "Incidencias Histórico  Project Manager",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitelIncidenciasHist.add(lblTitleIncidenciasHist);
            flxIncidenciasHist.add(flxTitelIncidenciasHist);
            flxContent.add(flxProyectos, flxIncidencias, flxIncidenciasHist);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxHeader": {
                        "skin": "sknFlxHeaderSmall",
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "headerIncidencia": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerIdProyecto": {
                    "title": "Id proyecto",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerProyecto": {
                    "title": "Proyecto",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerSolicitante": {
                    "title": "Solicitante",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerTipo": {
                    "title": "Tipo",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerEstado": {
                    "title": "Estado",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerTitulo": {
                    "title": "Titulo",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerObservaciones": {
                    "title": "Observaciones",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerCausa": {
                    "title": "Causa",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerSolucionado": {
                    "title": "Solucionado",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerMinutos": {
                    "title": "Minutos",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "headerFecha": {
                    "title": "Fecha",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(flxHeader, flxShadow, flxMenu, flxShadowMenu, flxUser, flxContent);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFlxHome",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});