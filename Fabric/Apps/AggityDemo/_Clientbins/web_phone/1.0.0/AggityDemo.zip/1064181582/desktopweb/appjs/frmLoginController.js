define("userfrmLoginController", {
    //Type your controller code here 
});
define("frmLoginControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_b2bd23eabadb4e9a9f89e914ec801bb9: function AS_Button_b2bd23eabadb4e9a9f89e914ec801bb9(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation("frmHome");
        ntf.navigate();
    }
});
define("frmLoginController", ["userfrmLoginController", "frmLoginControllerActions"], function() {
    var controller = require("userfrmLoginController");
    var controllerActions = ["frmLoginControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
